import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-part5',
  templateUrl: './part5.component.html',
  styleUrls: ['./part5.component.css']
})
export class Part5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
